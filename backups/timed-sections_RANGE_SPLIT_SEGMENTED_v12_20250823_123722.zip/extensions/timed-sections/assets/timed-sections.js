(function(){
  var SECTION_SELECTOR = '[id^="shopify-section-"], .shopify-section, [data-section-id]';
  var BLOCK_SELECTOR = '[id^="shopify-block-"], .shopify-block, [data-block-id]';

  function parseDate(value){
    if(!value) return null;
    var parts = String(value).trim().replace('T',' ').split(/[\s:.-]/);
    if(parts.length < 5) return new Date(value);
    var y = parseInt(parts[0],10);
    var m = parseInt(parts[1],10) - 1;
    var d = parseInt(parts[2],10);
    var hh = parseInt(parts[3],10) || 0;
    var mm = parseInt(parts[4],10) || 0;
    return new Date(y, m, d, hh, mm, 0);
  }

  function computeActive(startEl){
    var startStr = startEl.getAttribute('data-start-datetime');
    var endStr = startEl.getAttribute('data-end-datetime');
    var startAt = parseDate(startStr);
    var endAt = parseDate(endStr);
    var now = new Date();
    if(startAt && now < startAt) return false;
    if(endAt && now > endAt) return false;
    return true;
  }

  function getSection(el){
    if(!(el instanceof Element)) return null;
    return el.closest(SECTION_SELECTOR);
  }

  function getBlock(el){
    if(!(el instanceof Element)) return null;
    return el.closest(BLOCK_SELECTOR);
  }

  function isElement(el){ return el && el.nodeType === 1; }

  function findNextEnd(startEl){
    var all = document.querySelectorAll('.timed-sections-end');
    for(var i=0;i<all.length;i++){
      var endEl = all[i];
      if(startEl.compareDocumentPosition(endEl) & Node.DOCUMENT_POSITION_FOLLOWING){
        return endEl;
      }
    }
    return null;
  }

  // Collect block siblings after a given block inside the same section
  function collectBlocksAfter(startBlock, section){
    var items = [];
    if(!isElement(startBlock) || !isElement(section)) return items;
    var p = startBlock.parentElement;
    while(p && getSection(p) !== section){ p = p.parentElement; }
    if(!p) return items;
    var n = startBlock.nextElementSibling;
    while(n){
      if(getSection(n) !== section) break;
      items.push(n);
      n = n.nextElementSibling;
    }
    return items;
  }

  // Collect block siblings before a given block inside the same section
  function collectBlocksBefore(endBlock, section){
    var items = [];
    if(!isElement(endBlock) || !isElement(section)) return items;
    var p = endBlock.parentElement;
    while(p && getSection(p) !== section){ p = p.parentElement; }
    if(!p) return items;
    var cursor = endBlock.previousElementSibling;
    var stack = [];
    while(cursor){
      if(getSection(cursor) !== section) break;
      stack.push(cursor);
      cursor = cursor.previousElementSibling;
    }
    // reverse to keep document order
    for(var i=stack.length-1;i>=0;i--){ items.push(stack[i]); }
    return items;
  }

  // Collect top-level sections strictly between two section elements
  function collectSectionsBetween(startSection, endSection){
    var items = [];
    if(!isElement(startSection) || !isElement(endSection)) return items;
    var n = startSection.nextElementSibling;
    while(n && n !== endSection){
      // Only add element nodes; assume they are sections/containers at this level
      items.push(n);
      n = n.nextElementSibling;
    }
    return items;
  }

  // When start & end are in the same section, collect blocks strictly in-between
  function collectBlocksBetween(startBlock, endBlock){
    var items = [];
    if(!isElement(startBlock) || !isElement(endBlock)) return items;
    var n = startBlock.nextElementSibling;
    while(n && n !== endBlock){
      items.push(n);
      n = n.nextElementSibling;
    }
    return items;
  }

  function collectRangeElements(startEl){
    var endEl = findNextEnd(startEl);
    if(!endEl) return [];

    var startSection = getSection(startEl);
    var endSection = getSection(endEl);
    var startBlock = getBlock(startEl);
    var endBlock = getBlock(endEl);

    var items = [];

    if(startSection && endSection && startSection === endSection){
      // Same section: only blocks between start and end
      items = items.concat(collectBlocksBetween(startBlock, endBlock));
    } else {
      // Different sections: after start block in its section
      items = items.concat(collectBlocksAfter(startBlock, startSection));
      // Sections strictly between
      items = items.concat(collectSectionsBetween(startSection, endSection));
      // And blocks before the end block within its section
      items = items.concat(collectBlocksBefore(endBlock, endSection));
    }

    // Ensure start & end containers themselves are never included
    items = items.filter(function(el){ return el !== startBlock && el !== endBlock && el !== startSection && el !== endSection; });
    return items;
  }

  function applyState(elements, active){
    for(var i=0;i<elements.length;i++){
      var el = elements[i];
      if(!(el instanceof Element)) continue;
      if(active){
        el.classList.remove('ts-hidden');
        el.classList.add('ts-visible');
        el.style.removeProperty('display');
        el.style.removeProperty('visibility');
        el.style.removeProperty('pointer-events');
      } else {
        el.classList.add('ts-hidden');
        el.classList.remove('ts-visible');
        // Inline fallback in case CSS is missing
        el.style.visibility = 'hidden';
        el.style.pointerEvents = 'none';
      }
    }
  }

  function refresh(){
    var starts = document.querySelectorAll('.timed-sections-start');
    for(var i=0;i<starts.length;i++){
      var s = starts[i];
      var items = collectRangeElements(s);
      applyState(items, computeActive(s));
    }
  }

  function init(){
    refresh();
    setInterval(refresh, 5000);
    try{ new MutationObserver(refresh).observe(document.body, { childList: true, subtree: true }); }catch(e){}
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
